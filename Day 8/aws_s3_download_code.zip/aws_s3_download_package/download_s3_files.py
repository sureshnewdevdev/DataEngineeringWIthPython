"""
Download files from an AWS S3 bucket using Python and boto3.

Before running:
1. Install AWS CLI and configure credentials using: aws configure
2. Install boto3 using: pip install boto3
3. Update BUCKET_NAME and S3_PREFIX below.
"""

import os
import boto3
from botocore.exceptions import ClientError, NoCredentialsError


def download_files_from_s3(bucket_name: str, s3_prefix: str, local_download_folder: str) -> None:
    """
    Download files from an AWS S3 bucket.

    Args:
        bucket_name: Name of the S3 bucket.
        s3_prefix: Folder path inside the S3 bucket. Use empty string "" to download all files.
        local_download_folder: Local folder where files will be downloaded.
    """
    try:
        s3_client = boto3.client("s3")
        paginator = s3_client.get_paginator("list_objects_v2")

        pages = paginator.paginate(
            Bucket=bucket_name,
            Prefix=s3_prefix
        )

        file_count = 0

        for page in pages:
            if "Contents" not in page:
                print("No files found in the given S3 path.")
                return

            for obj in page["Contents"]:
                s3_key = obj["Key"]

                # Skip folder entries
                if s3_key.endswith("/"):
                    continue

                # Preserve folder structure locally
                relative_path = s3_key[len(s3_prefix):] if s3_prefix else s3_key
                local_file_path = os.path.join(local_download_folder, relative_path)

                # Create local folders if they do not exist
                local_dir = os.path.dirname(local_file_path)
                if local_dir:
                    os.makedirs(local_dir, exist_ok=True)

                print(f"Downloading: s3://{bucket_name}/{s3_key}")
                print(f"Saving to   : {local_file_path}")

                s3_client.download_file(
                    bucket_name,
                    s3_key,
                    local_file_path
                )

                file_count += 1

        print("--------------------------------")
        print("Download completed successfully.")
        print(f"Total files downloaded: {file_count}")

    except NoCredentialsError:
        print("AWS credentials not found.")
        print("Please run: aws configure")

    except ClientError as error:
        print("AWS error occurred:")
        print(error)

    except Exception as error:
        print("Unexpected error occurred:")
        print(error)


if __name__ == "__main__":
    # Step 1: Change this bucket name
    BUCKET_NAME = "YOUR_BUCKET_NAME"

    # Step 2: Use empty string to download all files from the bucket
    S3_PREFIX = ""

    # Example: To download only documents folder, use:
    # S3_PREFIX = "documents/"

    # Step 3: Local folder name where files will be downloaded
    LOCAL_DOWNLOAD_FOLDER = "s3_downloads"

    download_files_from_s3(
        BUCKET_NAME,
        S3_PREFIX,
        LOCAL_DOWNLOAD_FOLDER
    )
