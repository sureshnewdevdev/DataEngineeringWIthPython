AWS S3 File Download Using Python
=================================

This package contains a Python program to download files from an AWS S3 bucket.

Files included:
1. download_s3_files.py - Main Python program
2. README.txt - Step-by-step instructions

Step 1: Check Python
--------------------
Run:
python --version

If Python is not installed, install Python first.

Step 2: Install AWS CLI
-----------------------
Run:
aws --version

If AWS CLI is not installed, install AWS CLI Version 2.

Step 3: Configure AWS credentials
---------------------------------
Run:
aws configure

Enter:
AWS Access Key ID: your-access-key-id
AWS Secret Access Key: your-secret-access-key
Default region name: ap-south-1
Default output format: json

Step 4: Install boto3
---------------------
Run:
pip install boto3

or:
py -m pip install boto3

Step 5: Update the Python code
------------------------------
Open download_s3_files.py and change:
BUCKET_NAME = "YOUR_BUCKET_NAME"

Example:
BUCKET_NAME = "my-company-bucket"

To download all files:
S3_PREFIX = ""

To download only one folder:
S3_PREFIX = "documents/"

Step 6: Run the program
-----------------------
Run:
python download_s3_files.py

or:
py download_s3_files.py

Downloaded files will be stored in:
s3_downloads

Required IAM Permissions
------------------------
The IAM user needs:
- s3:ListBucket
- s3:GetObject

Sample IAM policy:

{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Action": ["s3:ListBucket"],
      "Resource": "arn:aws:s3:::YOUR_BUCKET_NAME"
    },
    {
      "Effect": "Allow",
      "Action": ["s3:GetObject"],
      "Resource": "arn:aws:s3:::YOUR_BUCKET_NAME/*"
    }
  ]
}

Common Errors
-------------
1. Unable to locate credentials
Fix: Run aws configure

2. Access Denied
Fix: Add s3:ListBucket and s3:GetObject permissions

3. No files found
Fix: Check bucket name and S3_PREFIX
